document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('measurementForm');

    if (form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }

            // Check measurement points and show warnings
            const minimo = parseFloat(document.getElementById('minimo').value);
            const maximo = parseFloat(document.getElementById('maximo').value);
            const points = document.getElementsByClassName('measurement-point');

            let outOfRange = false;
            for (let i = 0; i < points.length; i++) {
                const input = points[i].querySelector('input');
                const ponto = parseFloat(input.value);
                if (ponto < minimo || ponto > maximo) {
                    input.classList.add('is-invalid');
                    outOfRange = true;
                } else {
                    input.classList.remove('is-invalid');
                }
            }

            if (outOfRange) {
                // Show warning but allow submission
                if (confirm('Alguns pontos estão fora dos limites mínimo e máximo! Deseja continuar mesmo assim?')) {
                    return true;
                } else {
                    event.preventDefault();
                }
            }

            form.classList.add('was-validated');
        });

        // Real-time validation of min/max values
        document.getElementById('minimo').addEventListener('change', validateMinMax);
        document.getElementById('maximo').addEventListener('change', validateMinMax);
        document.getElementById('nominal').addEventListener('change', validateMinMax);
    }
});

function validateMinMax() {
    const minimo = parseFloat(document.getElementById('minimo').value);
    const maximo = parseFloat(document.getElementById('maximo').value);
    const nominal = parseFloat(document.getElementById('nominal').value);

    if (minimo >= maximo) {
        document.getElementById('minimo').setCustomValidity('O valor mínimo deve ser menor que o máximo');
        document.getElementById('maximo').setCustomValidity('O valor máximo deve ser maior que o mínimo');
    } else {
        document.getElementById('minimo').setCustomValidity('');
        document.getElementById('maximo').setCustomValidity('');
    }

    if (nominal < minimo || nominal > maximo) {
        // Show warning but don't prevent form submission
        document.getElementById('nominal').classList.add('is-invalid');
    } else {
        document.getElementById('nominal').classList.remove('is-invalid');
    }
    document.getElementById('nominal').setCustomValidity('');
}